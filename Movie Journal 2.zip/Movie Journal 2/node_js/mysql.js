// mysql.js - The Database Connection Pool Module

const mysql = require('mysql2/promise');

// Configuration details, following the class example.
const dbConfig = {
    host: "localhost",
    user: "root",
    password: "Funtana125G",
    database: "movie_journal",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
};

// Create and export the connection pool.
const pool = mysql.createPool(dbConfig);

// The setup script needs the settings before the database has been created.
pool.dbConfig = dbConfig;

// Check the database connection when the program starts.
pool.getConnection()
    .then(connection => {
        console.log("Database Pool: MySQL connection successful and pool established.");
        connection.release();
    })
    .catch(err => {
        console.error("Database Pool Error: Could not connect to MySQL! Check credentials and if the server is running.", err.message);
    });

module.exports = pool;
