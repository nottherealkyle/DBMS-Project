// Movie Journal DBMS final project
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const pool = require('./mysql');

const app = express();
const PORT = Number(process.env.PORT) || 3001;

// Read data submitted by HTML forms into req.body. Sessions keep the user ID
// between requests so each person sees their own watched and watchlist pages.
app.use(express.urlencoded({ extended: false, limit: '20kb' }));
app.use(session({
    name: 'moviejournal2.sid',
    secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex'),
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production' }
}));

// Send the shared stylesheet when a page requests /style.css.
app.get('/style.css', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'html', 'style.css'));
});

// User-written reviews and movie titles must be escaped before joining them into HTML.
// Helps prevent a review from inserting unwanted HTML or JavaScript into the page.
function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, character => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[character]);
}

// Each page is a separate HTML file. It takes the templates of HTML files and replaces placeholders
// with actual values from the database.
function renderHtml(name, values = {}) {
    const source = fs.readFileSync(path.join(__dirname, '..', 'html', `${name}.html`), 'utf8');
    return source.replace(/\{\{([A-Z0-9_]+)\}\}/g, (_, key) => {
        const value = values[key] == null ? '' : String(values[key]);
        return key.startsWith('RAW_') ? value : escapeHtml(value);
    });
}

// Wrap one page's content in layout.html, including navigation and messages.
// The navigation is shown only after the user has logged in.
// Used in case of errors as well
function page(req, title, body, active = '') {
    const loggedIn = Boolean(req.session.userId);
    const nav = loggedIn ? renderHtml('navigation', {
        RAW_MOVIES_ACTIVE: active === 'movies' ? 'aria-current="page"' : '',
        RAW_WATCHED_ACTIVE: active === 'watched' ? 'aria-current="page"' : '',
        RAW_WATCHLIST_ACTIVE: active === 'watchlist' ? 'aria-current="page"' : '',
        RAW_REVIEWS_ACTIVE: active === 'reviews' ? 'aria-current="page"' : '',
        USER_NAME: req.session.userName
    }) : '';
    const notice = req.query.notice ? `<div class="flash" role="status">${escapeHtml(req.query.notice)}</div>` : '';
    const error = req.query.error ? `<div class="flash error" role="alert">${escapeHtml(req.query.error)}</div>` : '';
    return renderHtml('layout', {
        TITLE: title, HOME_URL: loggedIn ? '/movies' : '/login',
        RAW_NAV: nav, RAW_NOTICES: notice + error, RAW_BODY: body
    });
}

// Reject invalid IDs before using movie or review IDs from a URL in SQL queries.
function validId(raw) {
    const value = Number(raw);
    return Number.isSafeInteger(value) && value > 0 ? value : null;
}

// Keep detailed server errors in the terminal while showing a simple browser message.
function failure(req, res, error) {
    console.error(error);
    res.status(500).send(page(req, 'Server error', renderHtml('message', { HEADING: 'Something went wrong', MESSAGE: 'Please try again.' })));
}

// Return to a page with a success notice or a form error in its URL.
// Notifies the user in case of any changes (e.g., moview added to watched or watch list).
function redirectMessage(res, url, kind, message) {
    res.redirect(`${url}${url.includes('?') ? '&' : '?'}${kind}=${encodeURIComponent(message)}`);
}

// Choose the first page based on whether this browser already has a login session.
// A new visitor sees the login page. A visitor who is already logged in goes straight to Movies.
app.get('/', (req, res) => res.redirect(req.session.userId ? '/movies' : '/login'));

// Show the login form from login.html.
app.get('/login', (req, res) => {
    if (req.session.userId) return res.redirect('/movies');
    res.send(page(req, 'Log in', renderHtml('login')));
});

// Look up the email, compare the submitted password with its stored hash,
// then save the matching user's ID and name in the session.
// REMEMBER - POST sends the form data
app.post('/login', async (req, res) => {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!email || !password) return redirectMessage(res, '/login', 'error', 'Enter your email and password.');
    try {
        const [rows] = await pool.execute('SELECT user_id, name, password_hash FROM users WHERE email = ?', [email]);
        if (rows.length !== 1 || !(await bcrypt.compare(password, rows[0].password_hash))) {
            return redirectMessage(res, '/login', 'error', 'Email or password is incorrect.');
        }
        req.session.regenerate(error => {
            if (error) return failure(req, res, error);
            req.session.userId = rows[0].user_id;
            req.session.userName = rows[0].name;
            res.redirect('/movies');
        });
    } catch (error) { failure(req, res, error); }
});

// Show the registration form from register.html.
app.get('/register', (req, res) => {
    if (req.session.userId) return res.redirect('/movies');
    res.send(page(req, 'Create account', renderHtml('register')));
});

// Validate a new account, hash its password, insert the user, and log them in.
// Two users with the same password will 10000% have different hashes
app.post('/register', async (req, res) => {
    const name = String(req.body.name || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (name.length < 2 || name.length > 100 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 255 || password.length < 8 || password.length > 72) {
        return redirectMessage(res, '/register', 'error', 'Enter a name, valid email, and password of 8 to 72 characters.');
    }
    try {
        const hash = await bcrypt.hash(password, 12);
        const [result] = await pool.execute('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)', [name, email, hash]);
        req.session.regenerate(error => {
            if (error) return failure(req, res, error);
            req.session.userId = result.insertId;
            req.session.userName = name;
            res.redirect('/movies');
        });
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') return redirectMessage(res, '/register', 'error', 'That email is already registered.');
        failure(req, res, error);
    }
});

// Delete the browser's login session and return to the login page.
app.post('/logout', (req, res) => {
    req.session.destroy(error => {
        if (error) return failure(req, res, error);
        res.clearCookie('connect.sid');
        res.redirect('/login');
    });
});

// A visitor without a session must log in. (if you try going to a watch list without being logged in)
// you get redirected to log in page
app.use((req, res, next) => {
    if (!req.session.userId) return res.redirect('/login');
    next();
});

// Search movie titles and show one page of results from MySQL. Average ratings
// are calculated from reviews rather than stored in the movies table.
app.get('/movies', async (req, res) => {
    const search = String(req.query.q || '').trim().slice(0, 100);
    const requestedPage = validId(req.query.page) || 1;
    const perPage = 24;
    try {
        const like = `%${search}%`;
        // Count matches first so the page can show the correct pagination links.
        const [countRows] = await pool.execute('SELECT COUNT(*) AS total FROM movies WHERE title LIKE ?', [like]);
        const total = countRows[0].total;
        const totalPages = Math.max(1, Math.ceil(total / perPage));
        const currentPage = Math.min(requestedPage, totalPages);
        const [movies] = await pool.execute(`
            SELECT m.movie_id, m.title, m.release_year, m.genre, m.director,
                   (SELECT ROUND(AVG(r.rating), 1) FROM reviews r WHERE r.movie_id = m.movie_id) AS average_rating
            FROM movies m WHERE m.title LIKE ? ORDER BY m.title, m.movie_id LIMIT ? OFFSET ?`,
            [like, perPage, (currentPage - 1) * perPage]);
        // Fill one movie_card.html template per SQL row, then insert them into movies.html.
        const cards = movies.map(movie => renderHtml('movie_card', {
            MOVIE_ID: movie.movie_id, TITLE: movie.title, GENRE: movie.genre,
            YEAR: movie.release_year, DIRECTOR: movie.director,
            AVERAGE_RATING: movie.average_rating == null ? 'Not rated yet' : `★ ${Number(movie.average_rating).toFixed(1)} / 5`
        })).join('');
        const query = `q=${encodeURIComponent(search)}`;
        const pagination = totalPages > 1 ? `<div class="pagination">
            ${currentPage > 1 ? `<a href="/movies?${query}&page=${currentPage - 1}">Previous</a>` : ''}
            <span>Page ${currentPage} of ${totalPages}</span>
            ${currentPage < totalPages ? `<a href="/movies?${query}&page=${currentPage + 1}">Next</a>` : ''}</div>` : '';
        const body = renderHtml('movies', {
            MATCH_COUNT: total, MATCH_LABEL: total === 1 ? 'movie' : 'movies', SEARCH: search,
            RAW_RESULTS: movies.length ? `<div class="grid">${cards}</div>` : '<div class="empty">No movies match that title.</div>',
            RAW_PAGINATION: pagination
        });
        res.send(page(req, 'Movies', body, 'movies'));
    } catch (error) { failure(req, res, error); }
});

// Show one movie, its average rating, trailer, community reviews, and the
// current user's watched/watchlist/review controls.
app.get('/movies/:movieId', async (req, res) => {
    const movieId = validId(req.params.movieId);
    if (!movieId) return res.status(404).send(page(req, 'Movie not found', '<h1>Movie not found</h1>'));
    try {
        const [movies] = await pool.execute(`SELECT m.*,
            (SELECT ROUND(AVG(r.rating), 1) FROM reviews r WHERE r.movie_id = m.movie_id) AS average_rating
            FROM movies m WHERE m.movie_id = ?`, [movieId]);
        if (!movies.length) return res.status(404).send(page(req, 'Movie not found', '<h1>Movie not found</h1>'));
        const movie = movies[0];
        // These three lookups decide which actions and review form the user can see.
        const [watchedRows] = await pool.execute('SELECT 1 FROM watched WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        const [watchlistRows] = await pool.execute('SELECT 1 FROM watchlist WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        const [ownRows] = await pool.execute('SELECT review_id, rating, review_text FROM reviews WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        const [reviews] = await pool.execute(`SELECT r.rating, r.review_text, DATE_FORMAT(r.created_at, '%Y-%m-%d') AS created_at, u.name
            FROM reviews r JOIN users u ON u.user_id = r.user_id
            WHERE r.movie_id = ? ORDER BY r.created_at DESC, r.review_id DESC`, [movieId]);

        // Convert a verified YouTube watch URL into an embeddable video URL.
        // A missing or invalid URL displays the unavailable message instead.
        let trailer = '<div class="empty">Trailer unavailable for this movie.</div>';
        if (movie.trailer_url) {
            try {
                const url = new URL(movie.trailer_url);
                const videoId = url.searchParams.get('v');
                if (url.protocol === 'https:' && ['youtube.com', 'www.youtube.com'].includes(url.hostname) && /^[A-Za-z0-9_-]{11}$/.test(videoId || '')) {
                    trailer = `<iframe class="video" src="https://www.youtube.com/embed/${videoId}" title="Trailer for ${escapeHtml(movie.title)}" loading="lazy" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>`;
                }
            } catch (_) { /* An invalid link displays the unavailable message. */ }
        }

        // Show either "mark as watched"/watchlist buttons or the watched state.
        let actions = '';
        if (watchedRows.length) {
            actions += `<span class="eyebrow">Watched</span><form method="post" action="/movies/${movieId}/unwatch"><button class="danger" type="submit">Remove from watched</button></form>`;
        } else {
            actions += `<form method="post" action="/movies/${movieId}/watched"><button type="submit">Mark as watched</button></form>`;
            actions += watchlistRows.length
                ? `<form method="post" action="/movies/${movieId}/unwatchlist"><button class="secondary" type="submit">Remove from watchlist</button></form>`
                : `<form method="post" action="/movies/${movieId}/watchlist"><button class="secondary" type="submit">Add to watchlist</button></form>`;
        }

        // Only watched movies have a review form; an existing review can be edited.
        let reviewForm = '<p class="muted">Mark this movie as watched to write a review.</p>';
        if (watchedRows.length) {
            const own = ownRows[0];
            const options = [1, 2, 3, 4, 5].map(rating => `<option value="${rating}" ${own && own.rating === rating ? 'selected' : ''}>${rating} star${rating === 1 ? '' : 's'}</option>`).join('');
            reviewForm = renderHtml('review_form', {
                FORM_ACTION: own ? `/reviews/${own.review_id}/update` : `/movies/${movieId}/reviews`,
                RAW_RATING_OPTIONS: options, REVIEW_TEXT: own ? own.review_text : '',
                BUTTON_TEXT: own ? 'Save review' : 'Post review',
                RAW_DELETE_FORM: own ? `<form method="post" action="/reviews/${own.review_id}/delete" style="margin-top:10px"><button class="danger" type="submit">Delete review</button></form>` : ''
            });
        }
        // Insert community reviews and the user's form into movie_detail.html.
        const reviewList = reviews.length ? reviews.map(review => renderHtml('movie_review', {
            REVIEWER: review.name, DATE: review.created_at, RATING: review.rating, TEXT: review.review_text
        })).join('') : '<p class="muted">No reviews yet.</p>';
        const body = renderHtml('movie_detail', {
            TITLE: movie.title, YEAR: movie.release_year, GENRE: movie.genre,
            DURATION: movie.duration_minutes, DIRECTOR: movie.director,
            AVERAGE_RATING: movie.average_rating == null ? 'Not rated yet' : `★ ${Number(movie.average_rating).toFixed(1)} / 5`,
            RAW_ACTIONS: actions, RAW_TRAILER: trailer, RAW_REVIEW_LIST: reviewList,
            REVIEW_HEADING: ownRows.length ? 'Edit your review' : 'Write a review',
            RAW_REVIEW_FORM: reviewForm
        });
        res.send(page(req, movie.title, body, 'movies'));
    } catch (error) { failure(req, res, error); }
});

// Add a movie to watched and remove it from the same user's watchlist.
// The transaction makes these two changes succeed or fail together.
app.post('/movies/:movieId/watched', async (req, res) => {
    const movieId = validId(req.params.movieId);
    if (!movieId) return res.status(400).send(page(req, 'Invalid movie', '<h1>Invalid movie ID</h1>'));
    const connection = await pool.getConnection().catch(error => { failure(req, res, error); return null; });
    if (!connection) return;
    try {
        await connection.beginTransaction();
        await connection.execute('INSERT INTO watched (user_id, movie_id, watched_at) VALUES (?, ?, CURDATE())', [req.session.userId, movieId]);
        await connection.execute('DELETE FROM watchlist WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        await connection.commit();
        redirectMessage(res, `/movies/${movieId}`, 'notice', 'Movie added to watched. You can now review it.');
    } catch (error) {
        await connection.rollback();
        if (error.code === 'ER_DUP_ENTRY') redirectMessage(res, `/movies/${movieId}`, 'error', 'This movie is already in your watched list.');
        else if (error.code === 'ER_NO_REFERENCED_ROW_2') res.status(404).send(page(req, 'Movie not found', '<h1>Movie not found</h1>'));
        else failure(req, res, error);
    } finally { connection.release(); }
});

// Add a movie to the user's watchlist only if they have not watched it already.
app.post('/movies/:movieId/watchlist', async (req, res) => {
    const movieId = validId(req.params.movieId);
    if (!movieId) return res.status(400).send(page(req, 'Invalid movie', '<h1>Invalid movie ID</h1>'));
    try {
        const [watchedRows] = await pool.execute('SELECT 1 FROM watched WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        if (watchedRows.length) return redirectMessage(res, `/movies/${movieId}`, 'error', 'A watched movie cannot be added to your watchlist.');
        await pool.execute('INSERT INTO watchlist (user_id, movie_id, added_at) VALUES (?, ?, CURDATE())', [req.session.userId, movieId]);
        redirectMessage(res, `/movies/${movieId}`, 'notice', 'Movie added to your watchlist.');
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') redirectMessage(res, `/movies/${movieId}`, 'error', 'This movie is already on your watchlist.');
        else if (error.code === 'ER_NO_REFERENCED_ROW_2') res.status(404).send(page(req, 'Movie not found', '<h1>Movie not found</h1>'));
        else failure(req, res, error);
    }
});

// Remove a movie from this user's watchlist without changing anyone else's list.
app.post('/movies/:movieId/unwatchlist', async (req, res) => {
    const movieId = validId(req.params.movieId);
    if (!movieId) return res.status(400).send(page(req, 'Invalid movie', '<h1>Invalid movie ID</h1>'));
    try {
        await pool.execute('DELETE FROM watchlist WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        redirectMessage(res, '/watchlist', 'notice', 'Movie removed from your watchlist.');
    } catch (error) { failure(req, res, error); }
});

// Remove a watched entry. MySQL prevents this while the user has a review for it,
// so the review must be deleted first.
app.post('/movies/:movieId/unwatch', async (req, res) => {
    const movieId = validId(req.params.movieId);
    if (!movieId) return res.status(400).send(page(req, 'Invalid movie', '<h1>Invalid movie ID</h1>'));
    try {
        await pool.execute('DELETE FROM watched WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        redirectMessage(res, '/watched', 'notice', 'Movie removed from watched.');
    } catch (error) {
        if (error.code === 'ER_ROW_IS_REFERENCED_2') redirectMessage(res, `/movies/${movieId}`, 'error', 'Delete your review before removing this movie from watched.');
        else failure(req, res, error);
    }
});

// Join watched entries to movie details and show the logged-in user's history.
app.get('/watched', async (req, res) => {
    try {
        const [rows] = await pool.execute(`SELECT m.movie_id, m.title, m.release_year, m.genre,
            DATE_FORMAT(w.watched_at, '%Y-%m-%d') AS watched_at,
            (SELECT ROUND(AVG(r.rating), 1) FROM reviews r WHERE r.movie_id = m.movie_id) AS average_rating,
            (SELECT review_id FROM reviews r WHERE r.user_id = w.user_id AND r.movie_id = w.movie_id) AS own_review_id
            FROM watched w JOIN movies m ON m.movie_id = w.movie_id
            WHERE w.user_id = ? ORDER BY w.watched_at DESC, m.title`, [req.session.userId]);
        const list = rows.length ? rows.map(row => renderHtml('watched_item', {
            MOVIE_ID: row.movie_id, TITLE: row.title, YEAR: row.release_year,
            GENRE: row.genre, WATCHED_DATE: row.watched_at,
            REVIEW_STATUS: row.own_review_id ? 'You reviewed this movie.' : 'You can add a review.',
            AVERAGE_RATING: row.average_rating == null ? '' : `Average ★ ${Number(row.average_rating).toFixed(1)}/5`
        })).join('') : '<div class="empty">You have not marked any movies as watched. <a href="/movies">Explore movies</a>.</div>';
        res.send(page(req, 'Watched', renderHtml('watched', {
            COUNT: rows.length, COUNT_LABEL: rows.length === 1 ? 'movie' : 'movies', RAW_LIST: list
        }), 'watched'));
    } catch (error) { failure(req, res, error); }
});

// Join watchlist entries to movies and display the newest review for each movie.
// If two reviews share a date, the larger review ID breaks the tie.
app.get('/watchlist', async (req, res) => {
    try {
        const [rows] = await pool.execute(`SELECT m.movie_id, m.title, m.release_year, m.genre,
            DATE_FORMAT(w.added_at, '%Y-%m-%d') AS added_at,
            r.review_text, r.rating, DATE_FORMAT(r.created_at, '%Y-%m-%d') AS review_date, u.name AS reviewer_name
            FROM watchlist w JOIN movies m ON m.movie_id = w.movie_id
            LEFT JOIN reviews r ON r.review_id = (
                SELECT r2.review_id FROM reviews r2 WHERE r2.movie_id = w.movie_id
                ORDER BY r2.created_at DESC, r2.review_id DESC LIMIT 1
            )
            LEFT JOIN users u ON u.user_id = r.user_id
            WHERE w.user_id = ? ORDER BY w.added_at DESC, m.title`, [req.session.userId]);
        const list = rows.length ? rows.map(row => renderHtml('watchlist_item', {
            MOVIE_ID: row.movie_id, TITLE: row.title, YEAR: row.release_year,
            GENRE: row.genre, ADDED_DATE: row.added_at,
            RAW_LATEST_REVIEW: row.review_text == null ? '<p class="small muted">No reviews yet.</p>' : renderHtml('latest_review', {
                REVIEWER: row.reviewer_name, DATE: row.review_date, RATING: row.rating, TEXT: row.review_text
            })
        })).join('') : '<div class="empty">Your watchlist is empty. <a href="/movies">Explore movies</a>.</div>';
        res.send(page(req, 'Watchlist', renderHtml('watchlist', { RAW_LIST: list }), 'watchlist'));
    } catch (error) { failure(req, res, error); }
});

// Search community reviews by reviewer name or movie title. The sort choice
// comes from a fixed list before it is added to the ORDER BY SQL clause.
app.get('/reviews', async (req, res) => {
    const search = String(req.query.q || '').trim().slice(0, 100);
    const sort = ['recent', 'reviewer', 'movie'].includes(req.query.sort) ? req.query.sort : 'recent';
    const order = sort === 'reviewer' ? 'u.name, m.title, r.created_at DESC' : sort === 'movie' ? 'm.title, u.name, r.created_at DESC' : 'r.created_at DESC, r.review_id DESC';
    try {
        const [rows] = await pool.execute(`SELECT r.rating, r.review_text, DATE_FORMAT(r.created_at, '%Y-%m-%d') AS created_at,
            u.name, m.movie_id, m.title FROM reviews r
            JOIN users u ON u.user_id = r.user_id JOIN movies m ON m.movie_id = r.movie_id
            WHERE u.name LIKE ? OR m.title LIKE ? ORDER BY ${order} LIMIT 200`, [`%${search}%`, `%${search}%`]);
        const list = rows.length ? rows.map(row => renderHtml('review_item', {
            REVIEWER: row.name, MOVIE_ID: row.movie_id, TITLE: row.title,
            DATE: row.created_at, RATING: row.rating, TEXT: row.review_text
        })).join('') : '<div class="empty">No reviews match that name or movie title.</div>';
        res.send(page(req, 'Community Reviews', renderHtml('reviews', {
            SEARCH: search, RAW_LIST: list,
            RAW_RECENT_SELECTED: sort === 'recent' ? 'selected' : '',
            RAW_REVIEWER_SELECTED: sort === 'reviewer' ? 'selected' : '',
            RAW_MOVIE_SELECTED: sort === 'movie' ? 'selected' : ''
        }), 'reviews'));
    } catch (error) { failure(req, res, error); }
});

// Validate and insert a new review only after this user watched the movie.
// The database also enforces this relationship with a foreign key.
app.post('/movies/:movieId/reviews', async (req, res) => {
    const movieId = validId(req.params.movieId);
    const rating = Number(req.body.rating);
    const reviewText = String(req.body.review_text || '').trim();
    if (!movieId || !Number.isInteger(rating) || rating < 1 || rating > 5 || !reviewText || reviewText.length > 1000) {
        return res.status(400).send(page(req, 'Invalid review', '<h1>Invalid review</h1><p>Choose a rating from 1 to 5 and write up to 1,000 characters.</p>'));
    }
    try {
        const [watchedRows] = await pool.execute('SELECT 1 FROM watched WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        if (!watchedRows.length) return redirectMessage(res, `/movies/${movieId}`, 'error', 'Mark the movie as watched before reviewing it.');
        await pool.execute('INSERT INTO reviews (user_id, movie_id, rating, review_text, created_at) VALUES (?, ?, ?, ?, CURDATE())',
            [req.session.userId, movieId, rating, reviewText]);
        redirectMessage(res, `/movies/${movieId}`, 'notice', 'Review posted.');
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') redirectMessage(res, `/movies/${movieId}`, 'error', 'You already reviewed this movie. Edit your existing review.');
        else if (error.code === 'ER_NO_REFERENCED_ROW_2') redirectMessage(res, `/movies/${movieId}`, 'error', 'Mark the movie as watched before reviewing it.');
        else failure(req, res, error);
    }
});

// Update a rating and review text after checking that this user owns the review.
app.post('/reviews/:reviewId/update', async (req, res) => {
    const reviewId = validId(req.params.reviewId);
    const rating = Number(req.body.rating);
    const reviewText = String(req.body.review_text || '').trim();
    if (!reviewId || !Number.isInteger(rating) || rating < 1 || rating > 5 || !reviewText || reviewText.length > 1000) {
        return res.status(400).send(page(req, 'Invalid review', '<h1>Invalid review</h1><p>Choose a rating from 1 to 5 and write up to 1,000 characters.</p>'));
    }
    try {
        const [rows] = await pool.execute('SELECT movie_id FROM reviews WHERE review_id = ? AND user_id = ?', [reviewId, req.session.userId]);
        if (!rows.length) return res.status(404).send(page(req, 'Review not found', '<h1>Review not found</h1>'));
        await pool.execute('UPDATE reviews SET rating = ?, review_text = ? WHERE review_id = ? AND user_id = ?', [rating, reviewText, reviewId, req.session.userId]);
        redirectMessage(res, `/movies/${rows[0].movie_id}`, 'notice', 'Review updated.');
    } catch (error) { failure(req, res, error); }
});

// Delete only a review written by the logged-in user.
app.post('/reviews/:reviewId/delete', async (req, res) => {
    const reviewId = validId(req.params.reviewId);
    if (!reviewId) return res.status(404).send(page(req, 'Review not found', '<h1>Review not found</h1>'));
    try {
        const [rows] = await pool.execute('SELECT movie_id FROM reviews WHERE review_id = ? AND user_id = ?', [reviewId, req.session.userId]);
        if (!rows.length) return res.status(404).send(page(req, 'Review not found', '<h1>Review not found</h1>'));
        await pool.execute('DELETE FROM reviews WHERE review_id = ? AND user_id = ?', [reviewId, req.session.userId]);
        redirectMessage(res, `/movies/${rows[0].movie_id}`, 'notice', 'Review deleted.');
    } catch (error) { failure(req, res, error); }
});

// Any URL not handled above receives a 404 page.
app.use((req, res) => res.status(404).send(page(req, 'Page not found', '<h1>Page not found</h1><p><a href="/movies">Back to movies</a></p>')));

// Start the Express server after all routes have been registered.
app.listen(PORT, () => console.log(`Movie Journal listening on http://localhost:${PORT}`));
