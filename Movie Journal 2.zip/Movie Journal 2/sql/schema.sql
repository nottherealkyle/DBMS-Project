CREATE DATABASE IF NOT EXISTS movie_journal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE movie_journal;

CREATE TABLE IF NOT EXISTS movies (
    movie_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    release_year SMALLINT NOT NULL,
    genre VARCHAR(100) NOT NULL,
    director VARCHAR(255) NOT NULL,
    duration_minutes SMALLINT UNSIGNED NOT NULL,
    trailer_url VARCHAR(500) NULL,
    images VARCHAR(500) NULL,
    CONSTRAINT chk_movie_year CHECK (release_year BETWEEN 1888 AND 2100),
    CONSTRAINT chk_movie_duration CHECK (duration_minutes > 0),
    INDEX idx_movie_title (title)
);

CREATE TABLE IF NOT EXISTS users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(60) NOT NULL
);

CREATE TABLE IF NOT EXISTS watched (
    user_id INT NOT NULL,
    movie_id INT NOT NULL,
    watched_at DATE NOT NULL,
    PRIMARY KEY (user_id, movie_id),
    CONSTRAINT fk_watched_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_watched_movie FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON DELETE CASCADE,
    INDEX idx_watched_date (user_id, watched_at)
);

CREATE TABLE IF NOT EXISTS watchlist (
    user_id INT NOT NULL,
    movie_id INT NOT NULL,
    added_at DATE NOT NULL,
    PRIMARY KEY (user_id, movie_id),
    CONSTRAINT fk_watchlist_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_watchlist_movie FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON DELETE CASCADE,
    INDEX idx_watchlist_date (user_id, added_at)
);

CREATE TABLE IF NOT EXISTS reviews (
    review_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    movie_id INT NOT NULL,
    rating TINYINT NOT NULL,
    review_text TEXT NOT NULL,
    created_at DATE NOT NULL,
    CONSTRAINT uq_review_user_movie UNIQUE (user_id, movie_id),
    CONSTRAINT chk_review_rating CHECK (rating BETWEEN 1 AND 5),
    CONSTRAINT fk_review_watched FOREIGN KEY (user_id, movie_id)
        REFERENCES watched(user_id, movie_id) ON DELETE RESTRICT,
    CONSTRAINT fk_review_movie FOREIGN KEY (movie_id) REFERENCES movies(movie_id) ON DELETE CASCADE,
    INDEX idx_review_movie_date (movie_id, created_at, review_id)
);
