// Add movie poster links to an existing database without changing user data.
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');
const pool = require('../node_js/mysql');

async function updateMovieImages() {
    const csvPath = path.join(__dirname, '..', 'movies.csv');
    const movies = parse(fs.readFileSync(csvPath, 'utf8'), {
        columns: true, skip_empty_lines: true, bom: true
    });
    const connection = await pool.getConnection();

    try {
        const [columns] = await connection.execute("SHOW COLUMNS FROM movies LIKE 'images'");
        if (columns.length === 0) {
            await connection.execute('ALTER TABLE movies ADD COLUMN images VARCHAR(500) NULL');
        }

        await connection.beginTransaction();
        for (const movie of movies) {
            await connection.execute(
                'UPDATE movies SET images = ? WHERE movie_id = ?',
                [movie.images || null, Number(movie.movie_id)]
            );
        }
        await connection.commit();
        console.log(`Updated poster links for ${movies.length} movies.`);
    } catch (error) {
        await connection.rollback();
        throw error;
    } finally {
        connection.release();
        await pool.end();
    }
}

updateMovieImages().catch(error => {
    console.error('Poster update failed:', error.message);
    process.exitCode = 1;
});
