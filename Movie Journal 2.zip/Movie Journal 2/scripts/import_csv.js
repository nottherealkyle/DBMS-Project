// Import the five supplied CSV files into an empty movie_journal database.
const fs = require('fs');
const path = require('path');
const { parse } = require('csv-parse/sync');
const pool = require('../node_js/mysql');

const root = path.join(__dirname, '..');

function csvRows(filename) {
    const contents = fs.readFileSync(path.join(root, filename), 'utf8');
    return parse(contents, { columns: true, skip_empty_lines: true, bom: true });
}

async function importData() {
    const movies = csvRows('movies.csv');
    const users = csvRows('users.csv');
    const watched = csvRows('watched.csv');
    const watchlist = csvRows('watchlist.csv');
    const reviews = csvRows('reviews.csv');
    const connection = await pool.getConnection();

    try {
        for (const table of ['movies', 'users', 'watched', 'watchlist', 'reviews']) {
            const [rows] = await connection.execute(`SELECT COUNT(*) AS total FROM ${table}`);
            if (rows[0].total !== 0) {
                throw new Error(`The ${table} table is not empty. Import into an empty database to avoid changing existing data.`);
            }
        }

        await connection.beginTransaction();

        for (const movie of movies) {
            await connection.execute(
                'INSERT INTO movies (movie_id, title, release_year, genre, director, duration_minutes, trailer_url, images) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [Number(movie.movie_id), movie.title, Number(movie.release_year), movie.genre, movie.director,
                    Number(movie.duration_minutes), movie.trailer_url || null, movie.images || null]
            );
        }

        for (const user of users) {
            await connection.execute(
                'INSERT INTO users (user_id, name, email, password_hash) VALUES (?, ?, ?, ?)',
                [Number(user.user_id), user.name, user.email, user.password_hash]
            );
        }

        for (const item of watched) {
            await connection.execute(
                'INSERT INTO watched (user_id, movie_id, watched_at) VALUES (?, ?, ?)',
                [Number(item.user_id), Number(item.movie_id), item.watched_at]
            );
        }

        for (const item of watchlist) {
            await connection.execute(
                'INSERT INTO watchlist (user_id, movie_id, added_at) VALUES (?, ?, ?)',
                [Number(item.user_id), Number(item.movie_id), item.added_at]
            );
        }

        for (const review of reviews) {
            await connection.execute(
                'INSERT INTO reviews (review_id, user_id, movie_id, rating, review_text, created_at) VALUES (?, ?, ?, ?, ?, ?)',
                [Number(review.review_id), Number(review.user_id), Number(review.movie_id),
                    Number(review.rating), review.review_text, review.created_at]
            );
        }

        await connection.commit();
        console.log(`Imported ${movies.length} movies, ${users.length} users, ${watched.length} watched entries, ${watchlist.length} watchlist entries, and ${reviews.length} reviews.`);
    } catch (error) {
        await connection.rollback();
        throw error;
    } finally {
        connection.release();
        await pool.end();
    }
}

importData().catch(error => {
    console.error('Import failed:', error.message);
    process.exitCode = 1;
});
