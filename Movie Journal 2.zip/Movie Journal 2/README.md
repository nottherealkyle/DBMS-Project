# Movie Journal 2 — team setup

This folder contains the Node.js app, separate `.html` page templates, MySQL schema, and five CSV datasets. Each teammate can run their own copy. The folder does not include `node_modules`. This local copy of `node_js/mysql.js` contains a MySQL password; remove or replace that password before sharing the folder with teammates.

The `.html` files in `html/` define the pages and repeated movie/review items. `node_js/server.js` reads those files, fills their `{{PLACEHOLDERS}}` with database results, and sends the finished HTML to the browser. Open the site through Node.js rather than opening a template file directly.

## 1. Install and open the project

Install Node.js (which includes npm) and MySQL, and make sure the MySQL server is running. Open a terminal in the `Movie Journal 2` folder. On a Mac, if the folder is on your Desktop:

```sh
cd "$HOME/Desktop/Movie Journal 2"
npm install
```

`npm install` downloads the packages listed in `package.json`. It creates a local `node_modules` directory; that directory does not need to be shared.

## 2. Configure MySQL in `mysql.js`

Open `node_js/mysql.js`. It follows the class example: `dbConfig` contains `host`, `user`, `password`, and `database`. Set these to the MySQL server you use. The database name should be `movie_journal`. Each teammate should put their own MySQL credentials in their copy. **Do not share a copy containing your real MySQL password.**

The current local copy is configured for this computer. No terminal `DB_PASSWORD` command is needed. If you edit `mysql.js`, stop and restart the Node server so it reads the new settings.

## 3. Create and fill the database (first time only)

```sh
npm run db:setup
npm run db:seed
```

`db:setup` creates the `movie_journal` database and its five tables. `db:seed` loads 1,000 movies, two users, 44 watched entries, 21 watchlist entries, and 12 reviews. Run `db:seed` **only once** on empty tables; it refuses to overwrite existing data. If your database is already set up and populated, skip this step.

## 4. Start the website

```sh
npm start
```

Open <http://localhost:3001> in a browser. This version uses port **3001** so it can run beside the original Movie Journal on port **3000**. Keep the terminal open while using the website. Press `Ctrl+C` to stop it. On later visits, run `npm start`; there is no need to seed again. If both versions point to the same MySQL database, changes made in one version appear in the other.

The seeded demo accounts are:

| Name | Email | Demo password |
| --- | --- | --- |
| Dan Shapovalov | `ds@gmail.com` | `123321` |
| Madeline Ashton | `ma@gmail.com` | `345543` |

These are demonstration accounts only. You can also register a new account, which starts with an empty watched list and watchlist.

## If something does not work

- **`Unknown database 'movie_journal'`:** Run `npm run db:setup`, then `npm run db:seed` if the tables are empty.
- **`Access denied for user`:** Check `host`, `user`, and `password` in `node_js/mysql.js`. The account also needs permission to create the database during setup.
- **`Cannot find module`:** Run `npm install` in this folder.
- **`db:seed` says a table is not empty:** The data has already been imported. Do not run the seed command again.
- **Port 3001 is in use:** On macOS/Linux run `PORT=3002 npm start`, or in PowerShell set `$env:PORT = '3002'` before `npm start`. Then open <http://localhost:3002>.

For a quick code syntax check, run `npm run check`.
