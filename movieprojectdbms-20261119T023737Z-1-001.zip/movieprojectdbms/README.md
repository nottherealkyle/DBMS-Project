# Movie Journal — team setup

This folder contains the Node.js app, MySQL schema, and five CSV datasets. Each teammate can run their own copy. The folder intentionally contains **no MySQL password** and no `node_modules` directory.

## 1. Install and open the project

Install Node.js (which includes npm) and MySQL, and make sure the MySQL server is running. Open a terminal in the `Movie Journal` folder. On a Mac, if the folder is on your Desktop:

```sh
cd "$HOME/Desktop/Movie Journal"
npm install
```

`npm install` downloads the packages listed in `package.json`. It creates a local `node_modules` directory; that directory does not need to be shared.

## 2. Set your own MySQL connection

The app reads these environment variables from your terminal. Use a MySQL account that can create a database and tables for first-time setup.

**macOS or Linux (zsh/bash):**

```sh
export DB_HOST=localhost
export DB_PORT=3306
export DB_USER=root
export DB_PASSWORD='YOUR_MYSQL_PASSWORD'
export DB_NAME=movie_journal
```

**Windows PowerShell:**

```powershell
$env:DB_HOST = 'localhost'
$env:DB_PORT = '3306'
$env:DB_USER = 'root'
$env:DB_PASSWORD = 'YOUR_MYSQL_PASSWORD'
$env:DB_NAME = 'movie_journal'
```

Replace `root` and the password with your own MySQL login if different. Change the host or port if your MySQL server uses different settings. These variables apply to the current terminal session, so set them again in a new terminal. Keep your real MySQL password private; do not add it to the shared folder.

## 3. Create and fill the database (first time only)

```sh
npm run db:setup
npm run db:seed
```

`db:setup` creates the `movie_journal` database and its five tables. `db:seed` loads 1,000 movies, two users, 44 watched entries, 21 watchlist entries, and 12 reviews. Run `db:seed` **only once** on empty tables; it refuses to overwrite existing data. If your database is already set up and populated, skip this step.

## 4. Start the website

```sh
npm start
```

Open <http://localhost:3000> in a browser. Keep the terminal open while using the website. Press `Ctrl+C` to stop it. On later visits, set your MySQL environment variables and run `npm start`; there is no need to seed again.

The seeded demo accounts are:

| Name | Email | Demo password |
| --- | --- | --- |
| Dan Shapovalov | `ds@gmail.com` | `123321` |
| Madeline Ashton | `ma@gmail.com` | `345543` |

These are demonstration accounts only. You can also register a new account, which starts with an empty watched list and watchlist.

## If something does not work

- **`Unknown database 'movie_journal'`:** Run `npm run db:setup`, then `npm run db:seed` if the tables are empty.
- **`Access denied for user`:** Check `DB_USER`, `DB_PASSWORD`, `DB_HOST`, and `DB_PORT`. The account also needs permission to create the database during setup.
- **`Cannot find module`:** Run `npm install` in this folder.
- **`db:seed` says a table is not empty:** The data has already been imported. Do not run the seed command again.
- **Port 3000 is in use:** On macOS/Linux run `PORT=3001 npm start`, or in PowerShell set `$env:PORT = '3001'` before `npm start`. Then open <http://localhost:3001>.

For a quick code syntax check, run `npm run check`.
