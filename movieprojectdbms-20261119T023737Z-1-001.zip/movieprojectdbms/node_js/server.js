// Movie Journal DBMS final project
// Browser -> Express server -> MySQL, following the course_search.js class example.
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const path = require('path');
const pool = require('./mysql');

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.urlencoded({ extended: false, limit: '20kb' }));
app.use(session({
    secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex'),
    resave: false,
    saveUninitialized: false,
    cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production' }
}));

app.get('/style.css', (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'html', 'style.css'));
});

// User-written reviews and movie titles must be escaped before joining them into HTML.
function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, character => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    })[character]);
}

function page(req, title, body, active = '') {
    const loggedIn = Boolean(req.session.userId);
    const nav = loggedIn ? `
        <nav aria-label="Main navigation">
            <a href="/movies" ${active === 'movies' ? 'aria-current="page"' : ''}>Movies</a>
            <a href="/watched" ${active === 'watched' ? 'aria-current="page"' : ''}>Watched</a>
            <a href="/watchlist" ${active === 'watchlist' ? 'aria-current="page"' : ''}>Watchlist</a>
            <a href="/reviews" ${active === 'reviews' ? 'aria-current="page"' : ''}>Community Reviews</a>
        </nav>
        <div class="user-menu"><span>${escapeHtml(req.session.userName)}</span>
            <form method="post" action="/logout"><button class="secondary" type="submit">Log out</button></form>
        </div>` : '';
    const notice = req.query.notice ? `<div class="flash" role="status">${escapeHtml(req.query.notice)}</div>` : '';
    const error = req.query.error ? `<div class="flash error" role="alert">${escapeHtml(req.query.error)}</div>` : '';
    return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${escapeHtml(title)} · Movie Journal</title><link rel="stylesheet" href="/style.css"></head>
        <body><header><div class="topbar"><a class="brand" href="${loggedIn ? '/movies' : '/login'}">Movie Journal</a>${nav}</div></header>
        <main>${notice}${error}${body}</main><footer>Movie Journal · DBMS final project</footer></body></html>`;
}

function validId(raw) {
    const value = Number(raw);
    return Number.isSafeInteger(value) && value > 0 ? value : null;
}

function failure(req, res, error) {
    console.error(error);
    res.status(500).send(page(req, 'Server error', '<h1>Something went wrong</h1><p>Please try again.</p>'));
}

function redirectMessage(res, url, kind, message) {
    res.redirect(`${url}${url.includes('?') ? '&' : '?'}${kind}=${encodeURIComponent(message)}`);
}

app.get('/', (req, res) => res.redirect(req.session.userId ? '/movies' : '/login'));

app.get('/login', (req, res) => {
    if (req.session.userId) return res.redirect('/movies');
    res.send(page(req, 'Log in', `<section class="panel auth-panel"><h1>Log in</h1><p class="lead">Your movies, reviews, and watchlist in one place.</p>
        <form method="post" action="/login"><label for="email">Email</label><input id="email" type="email" name="email" maxlength="255" required autocomplete="email">
        <label for="password">Password</label><input id="password" type="password" name="password" required autocomplete="current-password">
        <button type="submit">Log in</button></form><p class="small">New here? <a href="/register">Create an account</a></p></section>`));
});

app.post('/login', async (req, res) => {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!email || !password) return redirectMessage(res, '/login', 'error', 'Enter your email and password.');
    try {
        const [rows] = await pool.execute('SELECT user_id, name, password_hash FROM users WHERE email = ?', [email]);
        if (rows.length !== 1 || !(await bcrypt.compare(password, rows[0].password_hash))) {
            return redirectMessage(res, '/login', 'error', 'Email or password is incorrect.');
        }
        req.session.regenerate(error => {
            if (error) return failure(req, res, error);
            req.session.userId = rows[0].user_id;
            req.session.userName = rows[0].name;
            res.redirect('/movies');
        });
    } catch (error) { failure(req, res, error); }
});

app.get('/register', (req, res) => {
    if (req.session.userId) return res.redirect('/movies');
    res.send(page(req, 'Create account', `<section class="panel auth-panel"><h1>Create an account</h1>
        <form method="post" action="/register"><label for="name">Name</label><input id="name" name="name" maxlength="100" required autocomplete="name">
        <label for="email">Email</label><input id="email" type="email" name="email" maxlength="255" required autocomplete="email">
        <label for="password">Password</label><input id="password" type="password" name="password" minlength="8" maxlength="72" required autocomplete="new-password">
        <button type="submit">Create account</button></form><p class="small">Already have an account? <a href="/login">Log in</a></p></section>`));
});

app.post('/register', async (req, res) => {
    const name = String(req.body.name || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (name.length < 2 || name.length > 100 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 255 || password.length < 8 || password.length > 72) {
        return redirectMessage(res, '/register', 'error', 'Enter a name, valid email, and password of 8 to 72 characters.');
    }
    try {
        const hash = await bcrypt.hash(password, 12);
        const [result] = await pool.execute('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)', [name, email, hash]);
        req.session.regenerate(error => {
            if (error) return failure(req, res, error);
            req.session.userId = result.insertId;
            req.session.userName = name;
            res.redirect('/movies');
        });
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') return redirectMessage(res, '/register', 'error', 'That email is already registered.');
        failure(req, res, error);
    }
});

app.post('/logout', (req, res) => {
    req.session.destroy(error => {
        if (error) return failure(req, res, error);
        res.clearCookie('connect.sid');
        res.redirect('/login');
    });
});

// The following pages belong to the logged-in user.
app.use((req, res, next) => {
    if (!req.session.userId) return res.redirect('/login');
    next();
});

app.get('/movies', async (req, res) => {
    const search = String(req.query.q || '').trim().slice(0, 100);
    const requestedPage = validId(req.query.page) || 1;
    const perPage = 24;
    try {
        const like = `%${search}%`;
        const [countRows] = await pool.execute('SELECT COUNT(*) AS total FROM movies WHERE title LIKE ?', [like]);
        const total = countRows[0].total;
        const totalPages = Math.max(1, Math.ceil(total / perPage));
        const currentPage = Math.min(requestedPage, totalPages);
        const [movies] = await pool.execute(`
            SELECT m.movie_id, m.title, m.release_year, m.genre, m.director,
                   (SELECT ROUND(AVG(r.rating), 1) FROM reviews r WHERE r.movie_id = m.movie_id) AS average_rating
            FROM movies m WHERE m.title LIKE ? ORDER BY m.title, m.movie_id LIMIT ? OFFSET ?`,
            [like, perPage, (currentPage - 1) * perPage]);
        const cards = movies.map(movie => `<article class="panel movie-card"><span class="eyebrow">${escapeHtml(movie.genre)}</span>
            <h2><a href="/movies/${movie.movie_id}">${escapeHtml(movie.title)}</a></h2>
            <div class="meta">${movie.release_year} · Directed by ${escapeHtml(movie.director)}</div>
            <div class="card-foot"><span class="stars">${movie.average_rating == null ? 'Not rated yet' : `★ ${Number(movie.average_rating).toFixed(1)} / 5`}</span></div></article>`).join('');
        const query = `q=${encodeURIComponent(search)}`;
        const pagination = totalPages > 1 ? `<div class="pagination">
            ${currentPage > 1 ? `<a href="/movies?${query}&page=${currentPage - 1}">Previous</a>` : ''}
            <span>Page ${currentPage} of ${totalPages}</span>
            ${currentPage < totalPages ? `<a href="/movies?${query}&page=${currentPage + 1}">Next</a>` : ''}</div>` : '';
        res.send(page(req, 'Movies', `<h1>Explore movies</h1><p class="lead">Search ${total} matching ${total === 1 ? 'movie' : 'movies'} by title.</p>
            <form class="toolbar" method="get" action="/movies"><div class="grow"><label for="q">Movie title</label><input id="q" name="q" value="${escapeHtml(search)}" placeholder="Search movies"></div><button type="submit">Search</button></form>
            ${movies.length ? `<div class="grid">${cards}</div>${pagination}` : '<div class="empty">No movies match that title.</div>'}`, 'movies'));
    } catch (error) { failure(req, res, error); }
});

app.get('/movies/:movieId', async (req, res) => {
    const movieId = validId(req.params.movieId);
    if (!movieId) return res.status(404).send(page(req, 'Movie not found', '<h1>Movie not found</h1>'));
    try {
        const [movies] = await pool.execute(`SELECT m.*,
            (SELECT ROUND(AVG(r.rating), 1) FROM reviews r WHERE r.movie_id = m.movie_id) AS average_rating
            FROM movies m WHERE m.movie_id = ?`, [movieId]);
        if (!movies.length) return res.status(404).send(page(req, 'Movie not found', '<h1>Movie not found</h1>'));
        const movie = movies[0];
        const [watchedRows] = await pool.execute('SELECT 1 FROM watched WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        const [watchlistRows] = await pool.execute('SELECT 1 FROM watchlist WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        const [ownRows] = await pool.execute('SELECT review_id, rating, review_text FROM reviews WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        const [reviews] = await pool.execute(`SELECT r.rating, r.review_text, DATE_FORMAT(r.created_at, '%Y-%m-%d') AS created_at, u.name
            FROM reviews r JOIN users u ON u.user_id = r.user_id
            WHERE r.movie_id = ? ORDER BY r.created_at DESC, r.review_id DESC`, [movieId]);

        let trailer = '<div class="empty">Trailer unavailable for this movie.</div>';
        if (movie.trailer_url) {
            try {
                const url = new URL(movie.trailer_url);
                const videoId = url.searchParams.get('v');
                if (url.protocol === 'https:' && ['youtube.com', 'www.youtube.com'].includes(url.hostname) && /^[A-Za-z0-9_-]{11}$/.test(videoId || '')) {
                    trailer = `<iframe class="video" src="https://www.youtube.com/embed/${videoId}" title="Trailer for ${escapeHtml(movie.title)}" loading="lazy" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe>`;
                }
            } catch (_) { /* An invalid link displays the unavailable message. */ }
        }

        let actions = '';
        if (watchedRows.length) {
            actions += `<span class="eyebrow">Watched</span><form method="post" action="/movies/${movieId}/unwatch"><button class="danger" type="submit">Remove from watched</button></form>`;
        } else {
            actions += `<form method="post" action="/movies/${movieId}/watched"><button type="submit">Mark as watched</button></form>`;
            actions += watchlistRows.length
                ? `<form method="post" action="/movies/${movieId}/unwatchlist"><button class="secondary" type="submit">Remove from watchlist</button></form>`
                : `<form method="post" action="/movies/${movieId}/watchlist"><button class="secondary" type="submit">Add to watchlist</button></form>`;
        }

        let reviewForm = '<p class="muted">Mark this movie as watched to write a review.</p>';
        if (watchedRows.length) {
            const own = ownRows[0];
            const options = [1, 2, 3, 4, 5].map(rating => `<option value="${rating}" ${own && own.rating === rating ? 'selected' : ''}>${rating} star${rating === 1 ? '' : 's'}</option>`).join('');
            reviewForm = `<form method="post" action="${own ? `/reviews/${own.review_id}/update` : `/movies/${movieId}/reviews`}">
                <label for="rating">Rating</label><select id="rating" name="rating" required>${options}</select>
                <label for="review_text">Your review</label><textarea id="review_text" name="review_text" maxlength="1000" required>${own ? escapeHtml(own.review_text) : ''}</textarea>
                <div class="actions"><button type="submit">${own ? 'Save review' : 'Post review'}</button></div></form>`;
            if (own) reviewForm += `<form method="post" action="/reviews/${own.review_id}/delete" style="margin-top:10px"><button class="danger" type="submit">Delete review</button></form>`;
        }
        const reviewList = reviews.length ? reviews.map(review => `<article class="review"><div class="review-head"><strong>${escapeHtml(review.name)}</strong><span class="muted">${review.created_at} · <span class="stars">★ ${review.rating}/5</span></span></div><p>${escapeHtml(review.review_text)}</p></article>`).join('') : '<p class="muted">No reviews yet.</p>';
        res.send(page(req, movie.title, `<p><a href="/movies">← Back to movies</a></p><h1>${escapeHtml(movie.title)}</h1>
            <p class="lead">${movie.release_year} · ${escapeHtml(movie.genre)} · ${movie.duration_minutes} minutes</p>
            <div class="detail"><div class="stack"><section class="panel"><h2>Movie details</h2><dl class="facts"><dt>Director</dt><dd>${escapeHtml(movie.director)}</dd>
                <dt>Average rating</dt><dd>${movie.average_rating == null ? 'Not rated yet' : `★ ${Number(movie.average_rating).toFixed(1)} / 5`}</dd></dl>
                <div class="actions">${actions}</div></section><section class="panel"><h2>Trailer</h2>${trailer}</section>
                <section class="panel"><h2>Community reviews</h2>${reviewList}</section></div>
                <aside class="panel"><h2>${ownRows.length ? 'Edit your review' : 'Write a review'}</h2>${reviewForm}</aside></div>`, 'movies'));
    } catch (error) { failure(req, res, error); }
});

app.post('/movies/:movieId/watched', async (req, res) => {
    const movieId = validId(req.params.movieId);
    if (!movieId) return res.status(400).send(page(req, 'Invalid movie', '<h1>Invalid movie ID</h1>'));
    const connection = await pool.getConnection().catch(error => { failure(req, res, error); return null; });
    if (!connection) return;
    try {
        await connection.beginTransaction();
        await connection.execute('INSERT INTO watched (user_id, movie_id, watched_at) VALUES (?, ?, CURDATE())', [req.session.userId, movieId]);
        await connection.execute('DELETE FROM watchlist WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        await connection.commit();
        redirectMessage(res, `/movies/${movieId}`, 'notice', 'Movie added to watched. You can now review it.');
    } catch (error) {
        await connection.rollback();
        if (error.code === 'ER_DUP_ENTRY') redirectMessage(res, `/movies/${movieId}`, 'error', 'This movie is already in your watched list.');
        else if (error.code === 'ER_NO_REFERENCED_ROW_2') res.status(404).send(page(req, 'Movie not found', '<h1>Movie not found</h1>'));
        else failure(req, res, error);
    } finally { connection.release(); }
});

app.post('/movies/:movieId/watchlist', async (req, res) => {
    const movieId = validId(req.params.movieId);
    if (!movieId) return res.status(400).send(page(req, 'Invalid movie', '<h1>Invalid movie ID</h1>'));
    try {
        const [watchedRows] = await pool.execute('SELECT 1 FROM watched WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        if (watchedRows.length) return redirectMessage(res, `/movies/${movieId}`, 'error', 'A watched movie cannot be added to your watchlist.');
        await pool.execute('INSERT INTO watchlist (user_id, movie_id, added_at) VALUES (?, ?, CURDATE())', [req.session.userId, movieId]);
        redirectMessage(res, `/movies/${movieId}`, 'notice', 'Movie added to your watchlist.');
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') redirectMessage(res, `/movies/${movieId}`, 'error', 'This movie is already on your watchlist.');
        else if (error.code === 'ER_NO_REFERENCED_ROW_2') res.status(404).send(page(req, 'Movie not found', '<h1>Movie not found</h1>'));
        else failure(req, res, error);
    }
});

app.post('/movies/:movieId/unwatchlist', async (req, res) => {
    const movieId = validId(req.params.movieId);
    if (!movieId) return res.status(400).send(page(req, 'Invalid movie', '<h1>Invalid movie ID</h1>'));
    try {
        await pool.execute('DELETE FROM watchlist WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        redirectMessage(res, '/watchlist', 'notice', 'Movie removed from your watchlist.');
    } catch (error) { failure(req, res, error); }
});

app.post('/movies/:movieId/unwatch', async (req, res) => {
    const movieId = validId(req.params.movieId);
    if (!movieId) return res.status(400).send(page(req, 'Invalid movie', '<h1>Invalid movie ID</h1>'));
    try {
        await pool.execute('DELETE FROM watched WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        redirectMessage(res, '/watched', 'notice', 'Movie removed from watched.');
    } catch (error) {
        if (error.code === 'ER_ROW_IS_REFERENCED_2') redirectMessage(res, `/movies/${movieId}`, 'error', 'Delete your review before removing this movie from watched.');
        else failure(req, res, error);
    }
});

app.get('/watched', async (req, res) => {
    try {
        const [rows] = await pool.execute(`SELECT m.movie_id, m.title, m.release_year, m.genre,
            DATE_FORMAT(w.watched_at, '%Y-%m-%d') AS watched_at,
            (SELECT ROUND(AVG(r.rating), 1) FROM reviews r WHERE r.movie_id = m.movie_id) AS average_rating,
            (SELECT review_id FROM reviews r WHERE r.user_id = w.user_id AND r.movie_id = w.movie_id) AS own_review_id
            FROM watched w JOIN movies m ON m.movie_id = w.movie_id
            WHERE w.user_id = ? ORDER BY w.watched_at DESC, m.title`, [req.session.userId]);
        const list = rows.length ? rows.map(row => `<div class="item-row"><div><h3><a href="/movies/${row.movie_id}">${escapeHtml(row.title)}</a></h3>
            <p class="muted">${row.release_year} · ${escapeHtml(row.genre)} · Watched ${row.watched_at}</p>
            <p class="small">${row.own_review_id ? 'You reviewed this movie.' : 'You can add a review.'} ${row.average_rating == null ? '' : `Average ★ ${Number(row.average_rating).toFixed(1)}/5`}</p></div>
            <form method="post" action="/movies/${row.movie_id}/unwatch"><button class="danger" type="submit">Remove</button></form></div>`).join('') : '<div class="empty">You have not marked any movies as watched. <a href="/movies">Explore movies</a>.</div>';
        res.send(page(req, 'Watched', `<h1>Watched movies</h1><p class="lead">${rows.length} ${rows.length === 1 ? 'movie' : 'movies'} you have watched. Open one to write or edit a review.</p><section class="panel">${list}</section>`, 'watched'));
    } catch (error) { failure(req, res, error); }
});

app.get('/watchlist', async (req, res) => {
    try {
        const [rows] = await pool.execute(`SELECT m.movie_id, m.title, m.release_year, m.genre,
            DATE_FORMAT(w.added_at, '%Y-%m-%d') AS added_at,
            r.review_text, r.rating, DATE_FORMAT(r.created_at, '%Y-%m-%d') AS review_date, u.name AS reviewer_name
            FROM watchlist w JOIN movies m ON m.movie_id = w.movie_id
            LEFT JOIN reviews r ON r.review_id = (
                SELECT r2.review_id FROM reviews r2 WHERE r2.movie_id = w.movie_id
                ORDER BY r2.created_at DESC, r2.review_id DESC LIMIT 1
            )
            LEFT JOIN users u ON u.user_id = r.user_id
            WHERE w.user_id = ? ORDER BY w.added_at DESC, m.title`, [req.session.userId]);
        const list = rows.length ? rows.map(row => `<div class="item-row"><div><h3><a href="/movies/${row.movie_id}">${escapeHtml(row.title)}</a></h3>
            <p class="muted">${row.release_year} · ${escapeHtml(row.genre)} · Added ${row.added_at}</p>
            ${row.review_text == null ? '<p class="small muted">No reviews yet.</p>' : `<div class="review"><div class="review-head"><strong>Most recent review by ${escapeHtml(row.reviewer_name)}</strong><span class="muted">${row.review_date} · <span class="stars">★ ${row.rating}/5</span></span></div><p>${escapeHtml(row.review_text)}</p></div>`}</div>
            <form method="post" action="/movies/${row.movie_id}/unwatchlist"><button class="danger" type="submit">Remove</button></form></div>`).join('') : '<div class="empty">Your watchlist is empty. <a href="/movies">Explore movies</a>.</div>';
        res.send(page(req, 'Watchlist', `<h1>Your watchlist</h1><p class="lead">Movies you plan to watch, with the most recent community review when one exists.</p><section class="panel">${list}</section>`, 'watchlist'));
    } catch (error) { failure(req, res, error); }
});

app.get('/reviews', async (req, res) => {
    const search = String(req.query.q || '').trim().slice(0, 100);
    const sort = ['recent', 'reviewer', 'movie'].includes(req.query.sort) ? req.query.sort : 'recent';
    const order = sort === 'reviewer' ? 'u.name, m.title, r.created_at DESC' : sort === 'movie' ? 'm.title, u.name, r.created_at DESC' : 'r.created_at DESC, r.review_id DESC';
    try {
        const [rows] = await pool.execute(`SELECT r.rating, r.review_text, DATE_FORMAT(r.created_at, '%Y-%m-%d') AS created_at,
            u.name, m.movie_id, m.title FROM reviews r
            JOIN users u ON u.user_id = r.user_id JOIN movies m ON m.movie_id = r.movie_id
            WHERE u.name LIKE ? OR m.title LIKE ? ORDER BY ${order} LIMIT 200`, [`%${search}%`, `%${search}%`]);
        const list = rows.length ? rows.map(row => `<article class="review"><div class="review-head"><div><strong>${escapeHtml(row.name)}</strong> reviewed <a href="/movies/${row.movie_id}">${escapeHtml(row.title)}</a></div>
            <span class="muted">${row.created_at} · <span class="stars">★ ${row.rating}/5</span></span></div><p>${escapeHtml(row.review_text)}</p></article>`).join('') : '<div class="empty">No reviews match that name or movie title.</div>';
        res.send(page(req, 'Community Reviews', `<h1>Community reviews</h1><p class="lead">Find reviews by reviewer name or movie title.</p>
            <form class="toolbar" method="get" action="/reviews"><div class="grow"><label for="q">Reviewer or movie title</label><input id="q" name="q" value="${escapeHtml(search)}" placeholder="Search reviews"></div>
            <div><label for="sort">Sort by</label><select id="sort" name="sort"><option value="recent" ${sort === 'recent' ? 'selected' : ''}>Most recent</option><option value="reviewer" ${sort === 'reviewer' ? 'selected' : ''}>Reviewer name</option><option value="movie" ${sort === 'movie' ? 'selected' : ''}>Movie title</option></select></div>
            <button type="submit">Apply</button></form><section class="panel">${list}</section>`, 'reviews'));
    } catch (error) { failure(req, res, error); }
});

app.post('/movies/:movieId/reviews', async (req, res) => {
    const movieId = validId(req.params.movieId);
    const rating = Number(req.body.rating);
    const reviewText = String(req.body.review_text || '').trim();
    if (!movieId || !Number.isInteger(rating) || rating < 1 || rating > 5 || !reviewText || reviewText.length > 1000) {
        return res.status(400).send(page(req, 'Invalid review', '<h1>Invalid review</h1><p>Choose a rating from 1 to 5 and write up to 1,000 characters.</p>'));
    }
    try {
        const [watchedRows] = await pool.execute('SELECT 1 FROM watched WHERE user_id = ? AND movie_id = ?', [req.session.userId, movieId]);
        if (!watchedRows.length) return redirectMessage(res, `/movies/${movieId}`, 'error', 'Mark the movie as watched before reviewing it.');
        await pool.execute('INSERT INTO reviews (user_id, movie_id, rating, review_text, created_at) VALUES (?, ?, ?, ?, CURDATE())',
            [req.session.userId, movieId, rating, reviewText]);
        redirectMessage(res, `/movies/${movieId}`, 'notice', 'Review posted.');
    } catch (error) {
        if (error.code === 'ER_DUP_ENTRY') redirectMessage(res, `/movies/${movieId}`, 'error', 'You already reviewed this movie. Edit your existing review.');
        else if (error.code === 'ER_NO_REFERENCED_ROW_2') redirectMessage(res, `/movies/${movieId}`, 'error', 'Mark the movie as watched before reviewing it.');
        else failure(req, res, error);
    }
});

app.post('/reviews/:reviewId/update', async (req, res) => {
    const reviewId = validId(req.params.reviewId);
    const rating = Number(req.body.rating);
    const reviewText = String(req.body.review_text || '').trim();
    if (!reviewId || !Number.isInteger(rating) || rating < 1 || rating > 5 || !reviewText || reviewText.length > 1000) {
        return res.status(400).send(page(req, 'Invalid review', '<h1>Invalid review</h1><p>Choose a rating from 1 to 5 and write up to 1,000 characters.</p>'));
    }
    try {
        const [rows] = await pool.execute('SELECT movie_id FROM reviews WHERE review_id = ? AND user_id = ?', [reviewId, req.session.userId]);
        if (!rows.length) return res.status(404).send(page(req, 'Review not found', '<h1>Review not found</h1>'));
        await pool.execute('UPDATE reviews SET rating = ?, review_text = ? WHERE review_id = ? AND user_id = ?', [rating, reviewText, reviewId, req.session.userId]);
        redirectMessage(res, `/movies/${rows[0].movie_id}`, 'notice', 'Review updated.');
    } catch (error) { failure(req, res, error); }
});

app.post('/reviews/:reviewId/delete', async (req, res) => {
    const reviewId = validId(req.params.reviewId);
    if (!reviewId) return res.status(404).send(page(req, 'Review not found', '<h1>Review not found</h1>'));
    try {
        const [rows] = await pool.execute('SELECT movie_id FROM reviews WHERE review_id = ? AND user_id = ?', [reviewId, req.session.userId]);
        if (!rows.length) return res.status(404).send(page(req, 'Review not found', '<h1>Review not found</h1>'));
        await pool.execute('DELETE FROM reviews WHERE review_id = ? AND user_id = ?', [reviewId, req.session.userId]);
        redirectMessage(res, `/movies/${rows[0].movie_id}`, 'notice', 'Review deleted.');
    } catch (error) { failure(req, res, error); }
});

app.use((req, res) => res.status(404).send(page(req, 'Page not found', '<h1>Page not found</h1><p><a href="/movies">Back to movies</a></p>')));

app.listen(PORT, () => console.log(`Movie Journal listening on http://localhost:${PORT}`));
