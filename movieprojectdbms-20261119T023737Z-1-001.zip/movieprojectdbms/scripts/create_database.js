// Create the movie_journal database and tables using the connection in mysql.js.
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const pool = require('../node_js/mysql');

async function createDatabase() {
    const config = pool.dbConfig;
    const connection = await mysql.createConnection({
        host: config.host,
        port: config.port || 3306,
        user: config.user,
        password: config.password
    });

    try {
        const schema = fs.readFileSync(path.join(__dirname, '..', 'sql', 'schema.sql'), 'utf8');
        for (const statement of schema.split(';').map(text => text.trim()).filter(Boolean)) {
            await connection.query(statement);
        }
        console.log('movie_journal database and tables are ready.');
    } finally {
        await connection.end();
        await pool.end();
    }
}

createDatabase().catch(error => {
    console.error('Database setup failed:', error.message);
    process.exitCode = 1;
});
